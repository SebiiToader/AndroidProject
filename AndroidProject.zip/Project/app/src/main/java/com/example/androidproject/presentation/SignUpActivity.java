package com.example.androidproject.presentation;

public class SignUpActivity {
}
