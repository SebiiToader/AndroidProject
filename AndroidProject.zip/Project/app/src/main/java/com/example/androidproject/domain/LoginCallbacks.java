package com.example.androidproject.domain;

public interface LoginCallbacks {

    public void onSuccess(String message);

    public void onFailure(String message);
}

